var kefuhostlink = 'http://www.54kf.net/';

/* ͳ�ƹ��ܲ��ԡ�

document.writeln("<script type=\"text/javascript\">");
document.writeln("        var urls = [");
document.writeln("                \'http://123.56.97.126:7001/ws_da/da/ws.xhtml?id=1234567890&websiteId=1000000003\',");
document.writeln("                \'http://123.56.97.126:7001/ws_da/da/ws.xhtml?id=1234567891\'");
document.writeln("        ];");
document.writeln("    </script>");
document.writeln("    <script type=\"text/javascript\" src=\"http://123.56.97.126/ws_da/da/da.js\"></script>");


*/


